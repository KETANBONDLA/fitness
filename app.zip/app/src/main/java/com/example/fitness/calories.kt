import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import androidx.appcompat.app.AppCompatActivity

class CalorieCalculatorActivity : AppCompatActivity() {

    // Declare UI elements
    private lateinit var ageInput: TextInputEditText
    private lateinit var weightInput: TextInputEditText
    private lateinit var heightInput: TextInputEditText
    private lateinit var genderGroup: RadioGroup
    private lateinit var activityGroup: RadioGroup
    private lateinit var goalGroup: RadioGroup
    private lateinit var resultText: TextView
    private lateinit var calculateButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calories)

        // Initialize UI elements with updated IDs
        ageInput = findViewById(R.id.age_input)
        weightInput = findViewById(R.id.weight_input)
        heightInput = findViewById(R.id.height_input)
        genderGroup = findViewById(R.id.gender_group)
        activityGroup = findViewById(R.id.activity_level_group)
        goalGroup = findViewById(R.id.goal_group)
        resultText = findViewById(R.id.result_text)
        calculateButton = findViewById(R.id.calculate_button)

        // Set click listener for calculate button
        calculateButton.setOnClickListener {
            calculateCalories()
        }
    }

    private fun calculateCalories() {
        // Get the input values
        val age = ageInput.text.toString().toIntOrNull()
        val weight = weightInput.text.toString().toDoubleOrNull()
        val height = heightInput.text.toString().toDoubleOrNull()

        // Validate the inputs
        if (age == null || weight == null || height == null) {
            resultText.text = "Please fill in all fields correctly."
            return
        }

        // Determine the gender (Male/Female)
        val gender = when (genderGroup.checkedRadioButtonId) {
            R.id.radio_male -> "male"
            R.id.radio_female -> "female"
            else -> {
                resultText.text = "Please select a gender."
                return
            }
        }

        // Determine the activity level
        val activityLevel = when (activityGroup.checkedRadioButtonId) {
            R.id.radio_lightly_active -> 1.375
            R.id.radio_moderately_active -> 1.55
            R.id.radio_highly_active -> 1.725
            else -> {
                resultText.text = "Please select an activity level."
                return
            }
        }

        // Determine the goal
        val goal = when (goalGroup.checkedRadioButtonId) {
            R.id.radio_maintain -> 0.0
            R.id.radio_loss -> -500.0 // To lose weight
            R.id.radio_gain -> 500.0  // To gain weight
            else -> {
                resultText.text = "Please select a goal."
                return
            }
        }

        // Calculate BMR (Basal Metabolic Rate) using the Mifflin-St Jeor equation
        val bmr = if (gender == "male") {
            10 * weight + 6.25 * height - 5 * age + 5
        } else {
            10 * weight + 6.25 * height - 5 * age - 161
        }

        // Calculate TDEE (Total Daily Energy Expenditure)
        val tdee = bmr * activityLevel

        // Add goal adjustment (for weight loss or gain)
        val totalCalories = tdee + goal

        // Display the result
        resultText.text = "Your Total Daily Calories: %.2f kcal".format(totalCalories)
    }
}
